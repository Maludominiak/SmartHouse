#ifndef SMARTHOME_H
#define SMARTHOME_H

#include <string>
#include <vector>
#include <iostream>

class ComponenteRede {
protected:
    std::string ip;
    int nivelSinal;
public:
    ComponenteRede(const std::string& i, int s);
    virtual ~ComponenteRede() = default;
};
class InterfaceTela {
public:
    virtual ~InterfaceTela() = default;
    virtual void exibirImagem() = 0;
};
class DispositivoSmart : public ComponenteRede {
protected:
    std::string nome;
public:
    DispositivoSmart(const std::string& i, int s, const std::string& n);
    virtual ~DispositivoSmart() = default;
    virtual void ligar() = 0;
    std::string getNome() const { return nome; }
};
class LuzInteligente : public DispositivoSmart {
    int intensidadeDefault;
public:
    LuzInteligente(const std::string& i, int s, const std::string& n);
    void ligar() override;
    ~LuzInteligente() override = default;
};
class CaixaDeSom : public DispositivoSmart {
    int volume;
public:
    CaixaDeSom(const std::string& i, int s, const std::string& n, int vol = 75);
    void ligar() override;
    ~CaixaDeSom() override = default;
};
class SmartTV : public DispositivoSmart, public InterfaceTela {
    int brilho;
public:
    SmartTV(const std::string& i, int s, const std::string& n, int b = 80);
    void ligar() override;
    void exibirImagem() override;
    ~SmartTV() override = default;
};
class CameraSeguranca : protected ComponenteRede {
    std::string nome;
public:
    CameraSeguranca(const std::string& i, int s, const std::string& n);
    ~CameraSeguranca();
    void ligar();
    void monitorar();
};
class Comodo {
    std::string nome;
    std::vector<DispositivoSmart*> dispositivos;
public:
    Comodo(const std::string& n);
    ~Comodo();
    void adicionarDispositivo(DispositivoSmart* d);
    void ativarCena();
    std::string getNome() const;
};
class HubIA {
public:
    HubIA();
    ~HubIA();
    void processar();
};
class CasaInteligente {
    HubIA* processadorCentral;
public:
    CasaInteligente();
    ~CasaInteligente();
    void gerenciarCasa();
};
class Morador {
    std::string nome;
public:
    Morador(const std::string& n);
    ~Morador();
    void usarDispositivo(DispositivoSmart* d);
};

#endif // SMARTHOME_H

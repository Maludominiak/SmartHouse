#include "SmartHome.h"

ComponenteRede::ComponenteRede(const std::string& i, int s)
    : ip(i), nivelSinal(s)
{
}
//disp.
DispositivoSmart::DispositivoSmart(const std::string& i, int s, const std::string& n)
    : ComponenteRede(i, s), nome(n)
{
}

//luz
LuzInteligente::LuzInteligente(const std::string& i, int s, const std::string& n)
    : DispositivoSmart(i, s, n), intensidadeDefault(100)
{
}
void LuzInteligente::ligar() {
    std::cout << "[Luz] " << nome
              << " (IP: " << ip << ") ligada com intensidade "
              << intensidadeDefault << "%." << std::endl;
}

//som
CaixaDeSom::CaixaDeSom(const std::string& i, int s, const std::string& n, int vol)
    : DispositivoSmart(i, s, n), volume(vol)
{
}
void CaixaDeSom::ligar() {
    std::cout << "[Som] " << nome
              << " (IP: " << ip << ") ligada. Tocando playlist com volume "
              << volume << "%." << std::endl;
}

//TV
SmartTV::SmartTV(const std::string& i, int s, const std::string& n, int b)
    : DispositivoSmart(i, s, n), brilho(b)
{
}
void SmartTV::ligar() {
    std::cout << "[TV] " << nome
              << " (IP: " << ip << ") ligada. Ajustando brilho em "
              << brilho << "% e conectando ao streaming." << std::endl;
}
void SmartTV::exibirImagem() {
    std::cout << "[TV] " << nome << " exibindo imagem em resolução otimizada." << std::endl;
}

//camera
CameraSeguranca::CameraSeguranca(const std::string& i, int s, const std::string& n)
    : ComponenteRede(i, s), nome(n)
{
    std::cout << "[Camera] " << nome << " inicializada (monitoramento seguro)." << std::endl;
}
CameraSeguranca::~CameraSeguranca() {
    std::cout << "[Camera] " << nome << " encerrada." << std::endl;
}
void CameraSeguranca::ligar() {
    std::cout << "[Camera] " << nome << " ligada. Conectando via IP protegido "
              << ip << " (sinal " << nivelSinal << "%)." << std::endl;
}
void CameraSeguranca::monitorar() {
    std::cout << "[Camera] " << nome << " iniciando monitoramento seguro."
              << " (IP interno: " << ip << ", sinal: " << nivelSinal << "%)" << std::endl;
}

//comodo
Comodo::Comodo(const std::string& n) : nome(n) {
    std::cout << "[Comodo] '" << nome << "' criado." << std::endl;
}
Comodo::~Comodo() {
    std::cout << "[Comodo] '" << nome << "' destruído. Dispositivos agregados não são destruídos aqui." << std::endl;
}
void Comodo::adicionarDispositivo(DispositivoSmart* d) {
    if (d) {
        dispositivos.push_back(d);
        std::cout << "[Comodo] Dispositivo '" << d->getNome() << "' adicionado ao cômodo '" << nome << "'." << std::endl;
    }
}
void Comodo::ativarCena() {
    if (dispositivos.empty()) {
        std::cout << "[Comodo] Nenhum dispositivo para ativar em '" << nome << "'." << std::endl;
        return;
    }
    std::cout << "[Comodo] Ativando cena em '" << nome << "'..." << std::endl;
    for (auto d : dispositivos) {
        if (d) d->ligar(); // polimorfismo: cada classe implementa ligar() à sua maneira
    }
}
std::string Comodo::getNome() const {
    return nome;
}

//hubIA
HubIA::HubIA() {
    std::cout << "[HubIA] Processador de IA inicializado." << std::endl;
}
HubIA::~HubIA() {
    std::cout << "[HubIA] Processador de IA finalizado." << std::endl;
}
void HubIA::processar() {
    std::cout << "[HubIA] Analisando dados dos sensores e ajustando ambiente..." << std::endl;
}

//casa
CasaInteligente::CasaInteligente() { //"criar" hubIA
    processadorCentral = new HubIA();
    std::cout << "[Casa] CasaInteligente inicializada com HubIA (composição)." << std::endl;
}

CasaInteligente::~CasaInteligente() {
    delete processadorCentral;
    processadorCentral = nullptr;
    std::cout << "[Casa] CasaInteligente encerrada e HubIA destruído." << std::endl;
}

void CasaInteligente::gerenciarCasa() {
    std::cout << "[Casa] Gerenciamento automático iniciado." << std::endl;
    if (processadorCentral) processadorCentral->processar();
}

//morador
Morador::Morador(const std::string& n) : nome(n) {
    std::cout << "[Morador] " << nome << " chegou em casa." << std::endl;
}

Morador::~Morador() {
    std::cout << "[Morador] " << nome << " saiu." << std::endl;
}

void Morador::usarDispositivo(DispositivoSmart* d) {
    if (!d) {
        std::cout << "[Morador] Nenhum dispositivo fornecido." << std::endl;
        return;
    }
    std::cout << "[Morador] " << nome << " está usando o dispositivo '" << d->getNome() << "'." << std::endl;
    d->ligar();
    InterfaceTela* tela = dynamic_cast<InterfaceTela*>(d);
    if (tela) {
        tela->exibirImagem();
    }
}